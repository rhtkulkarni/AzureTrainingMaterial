dotnet msbuild .\build.msbuild
